#[TeleSurena](https://telegram.me/SurenaTeam)

#کلون یا هرگونه کپی برداری بدون ذکر منبع ممنوع و حلال نمی باشد

####اولین ربات کاملا فارسی برای سوپرگروه
####با امکانات فوق العاده
####منبع و پایه ربات : TeleSeed 

# نصب

####برای ران کردن ابتدا به سایت codeanywhere.com بروید و یا یک سرور مجازی تهیه کنید و بعد کد های زیر را در سرور خود وارد کنید

```sh
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev
sudo apt-get update
sudo apt-get upgrade
cd $HOME
git clone https://github.com/SurenaTeam/TeleSurena
cd TeleSurena
chmod +x launch.sh
./launch.sh install
./launch.sh 
```
